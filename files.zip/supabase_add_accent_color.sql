-- Run this in Supabase SQL Editor to add brand colour support
ALTER TABLE companies ADD COLUMN IF NOT EXISTS accent_color text default '#0D1F3C';
